const crypto = require('crypto');
const { Rcon } = require('rcon-client');

export const config = {
    api: { bodyParser: false },
};

// Rate limiting
const rateLimitMap = new Map();
const WINDOW_MS = 60_000;
const MAX_REQ = 5;

function getClientIP(req) {
    return (req.headers['x-forwarded-for'] || '').split(',')[0].trim() || 'unknown';
}

function isRateLimited(ip) {
    const now = Date.now();
    if (!rateLimitMap.has(ip)) {
        rateLimitMap.set(ip, { count: 1, start: now });
        return false;
    }
    const rec = rateLimitMap.get(ip);
    if (now - rec.start > WINDOW_MS) {
        rec.count = 1; rec.start = now;
        return false;
    }
    rec.count++;
    return rec.count > MAX_REQ;
}

async function getRawBody(req) {
    const chunks = [];
    for await (const chunk of req) chunks.push(chunk);
    return Buffer.concat(chunks).toString('utf8');
}

const rankHierarchy = {
    penduduk: 1,
    ksatria: 2,
    bangsawan: 3,
    pahlawan: 4,
};

const amountToRank = {
    '15000': 'penduduk',
    '35000': 'ksatria',
    '55000': 'bangsawan',
    '85000': 'pahlawan',
};

// Sanitasi username: izinkan huruf, angka, spasi, titik, strip, underscore. Panjang 3-32.
function sanitizeUsername(raw) {
    const clean = raw.trim();
    if (/^[a-zA-Z0-9 _.\-]{3,32}$/.test(clean)) {
        return clean;
    }
    return null;
}

module.exports = async function handler(req, res) {
    if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

    const ip = getClientIP(req);
    if (isRateLimited(ip)) return res.status(429).json({ error: 'Terlalu banyak request' });

    let rawBody;
    try { rawBody = await getRawBody(req); } catch { return res.status(400).end(); }

    // Verifikasi signature
    const sig = req.headers['x-saweria-signature'];
    const secret = process.env.SAWERIA_SECRET_KEY;
    if (!sig || !secret) return res.status(401).json({ error: 'Missing auth' });
    const computed = crypto.createHmac('sha256', secret).update(rawBody).digest('hex');
    if (sig !== computed) return res.status(401).json({ error: 'Invalid signature' });

    let payload;
    try { payload = JSON.parse(rawBody); } catch { return res.status(400).json({ error: 'Invalid JSON' }); }

    const { donator_name, amount_raw } = payload;
    if (!donator_name || amount_raw === undefined) return res.status(400).json({ error: 'Data tidak lengkap' });

    const rankTarget = amountToRank[String(amount_raw)];
    if (!rankTarget) return res.status(400).json({ error: 'Nominal tidak sesuai paket' });

    const username = sanitizeUsername(donator_name);
    if (!username) return res.status(400).json({ error: 'Username tidak valid' });

    const rconHost = process.env.RCON_HOST;
    const rconPort = parseInt(process.env.RCON_PORT, 10);
    const rconPassword = process.env.RCON_PASSWORD;
    if (!rconHost || !rconPort || !rconPassword) return res.status(500).json({ error: 'Konfigurasi RCON belum lengkap' });

    let rcon;
    try {
        rcon = new Rcon({ host: rconHost, port: rconPort, password: rconPassword });
        await rcon.connect();

        // Cek rank saat ini
        const infoCmd = `lp user "${username}" info`;
        const infoResponse = await rcon.send(infoCmd);
        let currentRank = null;
        for (const [rank, level] of Object.entries(rankHierarchy)) {
            if (infoResponse.includes(`- ${rank}`) || infoResponse.includes(`parent: ${rank}`)) {
                currentRank = rank;
                break;
            }
        }

        const currentLevel = currentRank ? rankHierarchy[currentRank] : 0;
        const targetLevel = rankHierarchy[rankTarget];

        if (targetLevel <= currentLevel) {
            await rcon.end();
            return res.status(400).json({ error: `Gagal! Kamu sudah memiliki rank ${currentRank || 'default'} yang setara atau lebih tinggi.` });
        }

        const setCmd = `lp user "${username}" parent set ${rankTarget}`;
        await rcon.send(setCmd);
        await rcon.end();

        return res.status(200).json({ success: true, message: `Rank ${rankTarget} diberikan kepada ${username}` });
    } catch (err) {
        console.error('RCON Error:', err);
        if (rcon && rcon.end) rcon.end().catch(() => {});
        return res.status(500).json({ error: 'Gagal menghubungi server Minecraft' });
    }
};