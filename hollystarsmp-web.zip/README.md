# ⭐ HollyStar SMP – Website

Website toko & penerima webhook Saweria untuk HollyStar SMP.

---

## 📁 Struktur Proyek

```
hollystarsmp-web/
├── public/
│   └── index.html        ← Tampilan depan toko
├── api/
│   └── webhook.js        ← Backend penerima webhook Saweria
├── package.json
├── vercel.json
└── .gitignore
```

---

## 🚀 Deploy ke Vercel

### 1. Install Vercel CLI & dependency

```bash
npm install
npm install -g vercel
```

### 2. Push ke GitHub, lalu hubungkan ke Vercel

Atau deploy langsung dari terminal:

```bash
vercel --prod
```

### 3. Atur Environment Variables di Vercel

Masuk ke **Vercel Dashboard → Project → Settings → Environment Variables**, lalu tambahkan:

| Key | Nilai | Wajib? |
|-----|-------|--------|
| `RCON_HOST` | IP publik server Minecraft | ✅ Ya |
| `RCON_PORT` | Port RCON (default: `25575`) | ✅ Ya |
| `RCON_PASSWORD` | Password RCON di `server.properties` | ✅ Ya |
| `DISCORD_WEBHOOK_URL` | URL webhook Discord (untuk notifikasi) | ❌ Opsional |
| `SAWERIA_SECRET` | Token rahasia dari Saweria (keamanan) | ❌ Opsional |

---

## ⚙️ Konfigurasi Server Minecraft

Pastikan di `server.properties` kamu:

```properties
enable-rcon=true
rcon.port=25575
rcon.password=PASSWORD_KAMU_DI_SINI
```

Restart server Minecraft setelah perubahan.

---

## 🔗 Setup Webhook Saweria

1. Login ke [Saweria](https://saweria.co)
2. Buka **Dashboard → Pengaturan → Webhook**
3. Masukkan URL: `https://NAMA-PROYEKMU.vercel.app/api/webhook`
4. (Opsional) Isi **Secret Token** dan salin ke env var `SAWERIA_SECRET`
5. Simpan.

---

## 📦 Format Pesan Donasi

Minta pembeli mengisi pesan donasi dengan format:

```
USERNAME | PAKET
```

Contoh: `Notch | VIP+`

Paket yang tersedia (bisa diubah di `api/webhook.js`):
- `vip`
- `vip+`
- `mvp`

---

## 🛠️ Kustomisasi

- **Tambah/ubah paket rank** → edit `PACKAGE_COMMANDS` di `api/webhook.js`
- **Ubah tampilan toko** → edit `public/index.html`
- **Plugin permission** → sesuaikan command di `PACKAGE_COMMANDS` (LuckPerms, PEX, dll.)

---

## 📄 Lisensi

Proyek pribadi – bebas dimodifikasi sesuai kebutuhan server kamu.
